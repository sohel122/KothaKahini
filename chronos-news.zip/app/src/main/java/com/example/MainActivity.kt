package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import com.example.data.ChronosDatabase
import com.example.data.ChronosRepository
import com.example.ui.ChronosAppContent
import com.example.ui.ChronosViewModel
import com.example.ui.ChronosViewModelFactory
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    // Instantiate local Room SQLite database
    val database = Room.databaseBuilder(
      applicationContext,
      ChronosDatabase::class.java,
      "chronos_db_v1"
    )
    .fallbackToDestructiveMigration()
    .build()
    
    val repository = ChronosRepository(database.dao())
    val viewModelFactory = ChronosViewModelFactory(repository)
    val viewModel = ViewModelProvider(this, viewModelFactory)[ChronosViewModel::class.java]

    setContent {
      val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
      
      MyApplicationTheme(darkTheme = isDark, dynamicColor = false) {
        ChronosAppContent(viewModel = viewModel)
      }
    }
  }
}
