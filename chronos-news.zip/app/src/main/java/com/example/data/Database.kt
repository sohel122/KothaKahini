package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "posts")
data class PublishPost(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val author: String,
    val type: String, // "BLOG" or "NEWS"
    val category: String, // "Technology", "Sports", "Breaking", "Local", "International", "Lifestyle"
    val imageUrl: String,
    val tags: String, // comma-separated
    val timestamp: Long = System.currentTimeMillis(),
    val likes: Int = 0,
    val views: Int = 0,
    val isFeatured: Boolean = false,
    val isTrending: Boolean = false
)

@Entity(tableName = "videos")
data class PublishVideo(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val videoUrl: String, // Simulated streaming URL
    val thumbnailUrl: String,
    val category: String,
    val likes: Int = 0,
    val views: Int = 0,
    val duration: String,
    val uploader: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class PostComment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val postId: Int = 0, // 0 if commenting on video
    val videoId: Int = 0, // 0 if commenting on post
    val author: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "users")
data class AppUser(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val username: String,
    val email: String,
    val role: String = "USER", // "USER" or "ADMIN"
    val avatarUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "newsletters")
data class NewsletterEmail(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val email: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Dao
interface ChronosDao {
    // Posts (Blog & News unified)
    @Query("SELECT * FROM posts ORDER BY timestamp DESC")
    fun getAllPosts(): Flow<List<PublishPost>>

    @Query("SELECT * FROM posts WHERE type = :type ORDER BY timestamp DESC")
    fun getPostsByType(type: String): Flow<List<PublishPost>>

    @Query("SELECT * FROM posts WHERE id = :id")
    suspend fun getPostById(id: Int): PublishPost?

    @Query("SELECT * FROM posts WHERE isFeatured = 1 ORDER BY timestamp DESC")
    fun getFeaturedPosts(): Flow<List<PublishPost>>

    @Query("SELECT * FROM posts WHERE isTrending = 1 ORDER BY timestamp DESC")
    fun getTrendingPosts(): Flow<List<PublishPost>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PublishPost): Long

    @Update
    suspend fun updatePost(post: PublishPost)

    @Query("DELETE FROM posts WHERE id = :id")
    suspend fun deletePostById(id: Int)

    // Videos
    @Query("SELECT * FROM videos ORDER BY timestamp DESC")
    fun getAllVideos(): Flow<List<PublishVideo>>

    @Query("SELECT * FROM videos WHERE id = :id")
    suspend fun getVideoById(id: Int): PublishVideo?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: PublishVideo): Long

    @Update
    suspend fun updateVideo(video: PublishVideo)

    @Query("DELETE FROM videos WHERE id = :id")
    suspend fun deleteVideoById(id: Int)

    // Comments
    @Query("SELECT * FROM comments WHERE postId = :postId ORDER BY timestamp ASC")
    fun getCommentsForPost(postId: Int): Flow<List<PostComment>>

    @Query("SELECT * FROM comments WHERE videoId = :videoId ORDER BY timestamp ASC")
    fun getCommentsForVideo(videoId: Int): Flow<List<PostComment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: PostComment)

    @Query("DELETE FROM comments WHERE id = :id")
    suspend fun deleteComment(id: Int)

    // Users
    @Query("SELECT * FROM users ORDER BY timestamp DESC")
    fun getAllUsers(): Flow<List<AppUser>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: AppUser): Long

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUserById(id: Int)

    // Newsletters
    @Query("SELECT * FROM newsletters ORDER BY timestamp DESC")
    fun getAllNewsletterEmails(): Flow<List<NewsletterEmail>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNewsletterEmail(email: NewsletterEmail)

    // Notifications
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<AppNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: Int)

    @Query("DELETE FROM notifications")
    suspend fun clearAllNotifications()
}

@Database(
    entities = [
        PublishPost::class,
        PublishVideo::class,
        PostComment::class,
        AppUser::class,
        NewsletterEmail::class,
        AppNotification::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ChronosDatabase : RoomDatabase() {
    abstract fun dao(): ChronosDao
}
