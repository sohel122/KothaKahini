package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ChronosRepository(private val dao: ChronosDao) {

    val allPosts: Flow<List<PublishPost>> = dao.getAllPosts()
    val blogPosts: Flow<List<PublishPost>> = dao.getPostsByType("BLOG")
    val newsPosts: Flow<List<PublishPost>> = dao.getPostsByType("NEWS")
    val featuredPosts: Flow<List<PublishPost>> = dao.getFeaturedPosts()
    val trendingPosts: Flow<List<PublishPost>> = dao.getTrendingPosts()
    val allVideos: Flow<List<PublishVideo>> = dao.getAllVideos()
    val allUsers: Flow<List<AppUser>> = dao.getAllUsers()
    val allNewsletterEmails: Flow<List<NewsletterEmail>> = dao.getAllNewsletterEmails()
    val allNotifications: Flow<List<AppNotification>> = dao.getAllNotifications()

    suspend fun getPostById(id: Int): PublishPost? = withContext(Dispatchers.IO) {
        dao.getPostById(id)
    }

    suspend fun insertPost(post: PublishPost): Long = withContext(Dispatchers.IO) {
        dao.insertPost(post)
    }

    suspend fun updatePost(post: PublishPost) = withContext(Dispatchers.IO) {
        dao.updatePost(post)
    }

    suspend fun deletePostById(id: Int) = withContext(Dispatchers.IO) {
        dao.deletePostById(id)
    }

    suspend fun getVideoById(id: Int): PublishVideo? = withContext(Dispatchers.IO) {
        dao.getVideoById(id)
    }

    suspend fun insertVideo(video: PublishVideo): Long = withContext(Dispatchers.IO) {
        dao.insertVideo(video)
    }

    suspend fun updateVideo(video: PublishVideo) = withContext(Dispatchers.IO) {
        dao.updateVideo(video)
    }

    suspend fun deleteVideoById(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteVideoById(id)
    }

    fun getCommentsForPost(postId: Int): Flow<List<PostComment>> = dao.getCommentsForPost(postId)

    fun getCommentsForVideo(videoId: Int): Flow<List<PostComment>> = dao.getCommentsForVideo(videoId)

    suspend fun insertComment(comment: PostComment) = withContext(Dispatchers.IO) {
        dao.insertComment(comment)
    }

    suspend fun deleteComment(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteComment(id)
    }

    suspend fun insertUser(user: AppUser): Long = withContext(Dispatchers.IO) {
        dao.insertUser(user)
    }

    suspend fun deleteUserById(id: Int) = withContext(Dispatchers.IO) {
        dao.deleteUserById(id)
    }

    suspend fun insertNewsletterEmail(email: String) = withContext(Dispatchers.IO) {
        dao.insertNewsletterEmail(NewsletterEmail(email = email))
    }

    suspend fun insertNotification(title: String, message: String) = withContext(Dispatchers.IO) {
        dao.insertNotification(AppNotification(title = title, message = message))
    }

    suspend fun markNotificationAsRead(id: Int) = withContext(Dispatchers.IO) {
        dao.markNotificationAsRead(id)
    }

    suspend fun clearAllNotifications() = withContext(Dispatchers.IO) {
        dao.clearAllNotifications()
    }

    suspend fun seedInitialDataIfEmpty() = withContext(Dispatchers.IO) {
        // Wait, check if posts are empty
        val currentPosts = dao.getAllPosts().first()
        if (currentPosts.isEmpty()) {
            val initialPosts = listOf(
                PublishPost(
                    title = "Gemini 3.5 Flash Supercharges Mobile AI Agents in 2026",
                    content = "Google's latest AI model release, Gemini 3.5 Flash, has taken the mobile app ecosystem by storm. Developers are reporting latency reductions of over 60% when running key-value lookups, contextual summaries, and multimodal reasoning interfaces directly inside Android containers. By utilizing advanced local key-value caches and compressed dynamic attention weights, the model runs gracefully on standard mobile hardware with negligible battery impact. Industry experts predict this will lead to a new wave of highly autonomous, self-correcting personal workspace agents that operate local databases and workflows seamlessly for users.",
                    author = "Elena Vance",
                    type = "NEWS",
                    category = "Technology",
                    imageUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
                    tags = "ai,gemini,google,android",
                    likes = 425,
                    views = 1530,
                    isFeatured = true,
                    isTrending = false
                ),
                PublishPost(
                    title = "The Art of Responsive UI Layouts in Jetpack Compose",
                    content = "Design is not just what it looks like; it's how it moves, layouts, and handles different form factors. Jetpack Compose introduced declarative layouts that make dynamic UI adjustments incredibly cohesive. By integrating BoxWithConstraints and WindowSizeClass managers, a single codebase can elegantly scale from a compact 5-inch handheld device up to an expanded 12-inch foldable or tablet screen. Developers should abandon rigid pixel-counting structures and embrace container-bound fluid elements, using weight modifiers, dynamic aspect ratios, and custom Canvas draw routines to establish fluid visual elegance.",
                    author = "Marcus Thorne",
                    type = "BLOG",
                    category = "Technology",
                    imageUrl = "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=800",
                    tags = "compose,kotlin,design,accessibility",
                    likes = 189,
                    views = 680,
                    isFeatured = false,
                    isTrending = true
                ),
                PublishPost(
                    title = "Global Summit Agrees on New Sustainable Zero-Tariff Silicon Corridors",
                    content = "At the 2026 Sustainable Tech Summit in Geneva, trade ministers from over 45 nations reached a landmark agreement to establish the first 'Zero-Tariff Silicon Corridors'. This legal pact eliminates target tariffs and trade barriers on eco-friendly semiconductors, locally manufactured micro-logic chips, and conflict-free rare earth mining machinery. The joint release declares that any facility meeting the ISO-2026 Carbon Neutral standard will enjoy unrestricted global distribution corridors, paving the way for scalable, decentralized electronics manufacturing across developing economies.",
                    author = "Sarah Jenkins",
                    type = "NEWS",
                    category = "International",
                    imageUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800",
                    tags = "global,sustainability,trade",
                    likes = 312,
                    views = 1102,
                    isFeatured = false,
                    isTrending = true
                ),
                PublishPost(
                    title = "Designing Minimalist Apps: Why 'Less is More' Outperforms AI Slop",
                    content = "As the digital space is increasingly crowded with cluttered layouts, automatic popups, and non-functional AI widgets, clean intentionalism is the new luxury. True design craftsmanship focuses on robust spacing rules, high-contrast monochrome typography, and substantial negative space that allows the content to guide the focus. In this essay, we outline key rules for mobile screen spacing: limit active components, pair an iconic display font with high-readability body copy, and use elevation only to declare clear structural inheritance rather than decoration.",
                    author = "Julius K",
                    type = "BLOG",
                    category = "Lifestyle",
                    imageUrl = "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800",
                    tags = "design,ux,minimalism,art",
                    likes = 290,
                    views = 780,
                    isFeatured = false,
                    isTrending = false
                ),
                PublishPost(
                    title = "Championship Finals: Underdog FC Seizes League Title in 94th Minute",
                    content = "In what sportscasters are already calling the most dramatic professional football final of the decade, the underdog athletic club clinched the cup in the final seconds of injury time. Down 1-2 in the 88th minute, a quick-fire header following a corner kick equalized the match, setting up a breathtaking close. At 93:45, a spectacular bicycle kick from substitute striker Leo Cruz blasted past the defending champion's goalkeeper. The stadium erupted in celebration as the final whistle blew, cementing an unforgettable cinematic triumph.",
                    author = "Dave Miller",
                    type = "NEWS",
                    category = "Sports",
                    imageUrl = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=800",
                    tags = "sports,finals,champions",
                    likes = 540,
                    views = 2800,
                    isFeatured = false,
                    isTrending = true
                ),
                PublishPost(
                    title = "City Council Approves New City-Wide Micro-Forest Project",
                    content = "Local administration has approved a $12M municipal budget to plant 25 compact micro-forests across urban centers. Utilizing the Japanese Miyawaki planting method, these miniature forests grow up to 10 times faster and are 30 times denser than standard plantations. The initiative aims to reduce temperature islands, restore native songbird habitats, and absorb heavy carbon dioxide particles within high-traffic industrial corridors, creating cleaner spaces for local neighborhoods.",
                    author = "Nadia Vance",
                    type = "NEWS",
                    category = "Local",
                    imageUrl = "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800",
                    tags = "local,nature,city",
                    likes = 120,
                    views = 430,
                    isFeatured = false,
                    isTrending = false
                )
            )

            for (post in initialPosts) {
                dao.insertPost(post)
            }
        }

        // Check if videos are empty
        val currentVideos = dao.getAllVideos().first()
        if (currentVideos.isEmpty()) {
            val initialVideos = listOf(
                PublishVideo(
                    title = "Introducing Chronos Next-Gen Publishing Suite",
                    description = "Take an exclusive inside look at the engineering and creative choices behind Chronos, the modern, scalable 2026 digital publishing and audio system built on Jetpack Compose and Room SQL.",
                    videoUrl = "https://www.w3schools.com/html/mov_bbb.mp4", // Reliable public mp4 asset
                    thumbnailUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800",
                    category = "Tech",
                    likes = 245,
                    views = 1200,
                    duration = "2:30",
                    uploader = "Elena Vance"
                ),
                PublishVideo(
                    title = "Futuristic Tokyo Urban Walk in Ultra HD",
                    description = "A peaceful exploration of Shibuya and Shinjuku districts in early 2026, showcasing high-resolution futuristic OLED billboards, carbon-neutral automated logistics pods, and vertical micro-forest gardens.",
                    videoUrl = "https://www.w3schools.com/html/movie.mp4",
                    thumbnailUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800",
                    category = "Travel",
                    likes = 582,
                    views = 3105,
                    duration = "1:05",
                    uploader = "Chronos Global"
                ),
                PublishVideo(
                    title = "Miyawaki Planting Method: Fast Micro-Forests",
                    description = "Learn how local botanists prepare high-density organic soil to plant highly resilient urban micro-forests that grow up to 10x faster and naturally clean city air.",
                    videoUrl = "https://www.w3schools.com/html/mov_bbb.mp4",
                    thumbnailUrl = "https://images.unsplash.com/photo-1448375240586-882707db888b?w=800",
                    category = "Nature",
                    likes = 94,
                    views = 350,
                    duration = "2:30",
                    uploader = "GreenCity Org"
                )
            )

            for (video in initialVideos) {
                dao.insertVideo(video)
            }
        }

        // Check if comments are empty
        val posts = dao.getAllPosts().first()
        if (posts.isNotEmpty()) {
            val targetPostId = posts[0].id
            val initialComments = listOf(
                PostComment(postId = targetPostId, author = "Sarah K.", content = "This is a fantastic analysis! Gemini 3.5 Flash is indeed showing incredible speed of response on mobile platforms. Extremely excited for local models in 2026."),
                PostComment(postId = targetPostId, author = "Liam Vance", content = "Does this support multi-turn offline chats as well? Standard key-value databases are super elegant for managing context weights locally.")
            )
            for (comment in initialComments) {
                dao.insertComment(comment)
            }
        }

        // Add preseeded notification
        val currentNotifications = dao.getAllNotifications().first()
        if (currentNotifications.isEmpty()) {
            dao.insertNotification(
                AppNotification(
                    title = "Welcome to Chronos News",
                    message = "Experience the premium, lightning-fast digital news and blogging client of 2026. Create posts, watch videos, comment, and inspect deep SEO metadata!"
                )
            )
        }

        // Seed default admins/users
        val currentUsers = dao.getAllUsers().first()
        if (currentUsers.isEmpty()) {
            dao.insertUser(AppUser(username = "Elena Vance", email = "elena.vance@chronos.org", role = "ADMIN"))
            dao.insertUser(AppUser(username = "John Doe", email = "john.doe@gmail.com", role = "USER"))
        }
    }
}
