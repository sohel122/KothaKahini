package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class AppScreen {
    object Home : AppScreen()
    object BlogList : AppScreen()
    object VideoList : AppScreen()
    object AdminDashboard : AppScreen()
    object AboutContact : AppScreen()
    data class PostDetail(val postId: Int) : AppScreen()
    data class VideoDetail(val videoId: Int) : AppScreen()
    data class EditPostScreen(val postId: Int?) : AppScreen() // null for and-create
}

class ChronosViewModel(private val repository: ChronosRepository) : ViewModel() {

    // Seeding and Init
    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    // App Preferences / Settings
    private val _isDarkMode = MutableStateFlow(true) // Premium dark is default in 2026
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }

    // Navigation state
    private val _currentScreen = MutableStateFlow<AppScreen>(AppScreen.Home)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val navStack = mutableListOf<AppScreen>(AppScreen.Home)

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            navStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (navStack.isNotEmpty()) {
            val prev = navStack.removeAt(navStack.lastIndex)
            _currentScreen.value = prev
            return true
        }
        return false
    }

    // Active Authenticated User
    private val _currentUser = MutableStateFlow<AppUser?>(
        AppUser(id = 1, username = "Elena Vance", email = "elena.vance@chronos.org", role = "ADMIN")
    )
    val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

    fun loginUser(name: String, email: String, isAdmin: Boolean) {
        viewModelScope.launch {
            val user = AppUser(
                username = name,
                email = email,
                role = if (isAdmin) "ADMIN" else "USER",
                avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100"
            )
            val id = repository.insertUser(user)
            _currentUser.value = user.copy(id = id.toInt())
            sendLocalAlert("Welcome back, $name!", "You have successfully signed in as ${user.role}.")
        }
    }

    fun signUpUser(name: String, email: String) {
        loginUser(name, email, false)
    }

    fun logoutUser() {
        _currentUser.value = null
        sendLocalAlert("Signed Out", "You have signed out of Chronos News.")
    }

    // Dynamic Lists from Database
    val allPosts: StateFlow<List<PublishPost>> = repository.allPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVideos: StateFlow<List<PublishVideo>> = repository.allVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<AppUser>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNewsletterEmails: StateFlow<List<NewsletterEmail>> = repository.allNewsletterEmails
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtering, Search and Category States
    private val _newsSearchQuery = MutableStateFlow("")
    val newsSearchQuery: StateFlow<String> = _newsSearchQuery.asStateFlow()

    fun setNewsSearchQuery(query: String) {
        _newsSearchQuery.value = query
    }

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    private val _videoSearchQuery = MutableStateFlow("")
    val videoSearchQuery: StateFlow<String> = _videoSearchQuery.asStateFlow()

    fun setVideoSearchQuery(query: String) {
        _videoSearchQuery.value = query
    }

    private val _selectedVideoCategory = MutableStateFlow("All")
    val selectedVideoCategory: StateFlow<String> = _selectedVideoCategory.asStateFlow()

    fun setVideoCategory(category: String) {
        _selectedVideoCategory.value = category
    }

    // User alerts/notifications state
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun triggerSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    // Dynamic Comments Fetch
    fun getCommentsForPost(postId: Int): Flow<List<PostComment>> = repository.getCommentsForPost(postId)

    fun getCommentsForVideo(videoId: Int): Flow<List<PostComment>> = repository.getCommentsForVideo(videoId)

    // Interaction CRUD

    fun addPost(title: String, content: String, author: String, type: String, category: String, tags: String, imageUrl: String) {
        viewModelScope.launch {
            val finalImage = if (imageUrl.isBlank()) {
                "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800"
            } else {
                imageUrl
            }
            val newPost = PublishPost(
                title = title,
                content = content,
                author = author,
                type = type, // "BLOG" or "NEWS"
                category = category,
                tags = tags,
                imageUrl = finalImage,
                isFeatured = false,
                isTrending = true
            )
            repository.insertPost(newPost)
            triggerSnackbar("${type.lowercase().replaceFirstChar { it.uppercase() }} publication created successfully!")
            sendLocalAlert("New Publication Online", "\"$title\" is now live on Chronos.")
        }
    }

    fun updatePost(id: Int, title: String, content: String, author: String, type: String, category: String, tags: String, imageUrl: String) {
        viewModelScope.launch {
            val existing = repository.getPostById(id)
            if (existing != null) {
                val updated = existing.copy(
                    title = title,
                    content = content,
                    author = author,
                    type = type,
                    category = category,
                    tags = tags,
                    imageUrl = if (imageUrl.isBlank()) existing.imageUrl else imageUrl
                )
                repository.updatePost(updated)
                triggerSnackbar("Publication updated successfully!")
            }
        }
    }

    fun deletePost(id: Int, title: String) {
        viewModelScope.launch {
            repository.deletePostById(id)
            triggerSnackbar("\"$title\" has been removed.")
        }
    }

    fun uploadVideo(title: String, description: String, category: String, duration: String, videoUrl: String, thumbnailUrl: String) {
        viewModelScope.launch {
            val finalThumb = if (thumbnailUrl.isBlank()) {
                "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800"
            } else {
                thumbnailUrl
            }
            val newVideo = PublishVideo(
                title = title,
                description = description,
                category = category,
                duration = duration.ifBlank { "3:10" },
                videoUrl = videoUrl.ifBlank { "https://www.w3schools.com/html/mov_bbb.mp4" },
                thumbnailUrl = finalThumb,
                uploader = _currentUser.value?.username ?: "Chronos Creator"
            )
            repository.insertVideo(newVideo)
            triggerSnackbar("Video uploaded and rendering successfully!")
            sendLocalAlert("New Video Published", "\"$title\" has been shared.")
        }
    }

    fun deleteVideo(id: Int, title: String) {
        viewModelScope.launch {
            repository.deleteVideoById(id)
            triggerSnackbar("Video \"$title\" has been deleted.")
        }
    }

    fun incrementPostViews(post: PublishPost) {
        viewModelScope.launch {
            repository.updatePost(post.copy(views = post.views + 1))
        }
    }

    fun incrementVideoViews(video: PublishVideo) {
        viewModelScope.launch {
            repository.updateVideo(video.copy(views = video.views + 1))
        }
    }

    fun likePost(post: PublishPost) {
        viewModelScope.launch {
            repository.updatePost(post.copy(likes = post.likes + 1))
            triggerSnackbar("Liked \"${post.title}\"")
        }
    }

    fun likeVideo(video: PublishVideo) {
        viewModelScope.launch {
            repository.updateVideo(video.copy(likes = video.likes + 1))
            triggerSnackbar("Liked video: \"${video.title}\"")
        }
    }

    fun addPostComment(postId: Int, author: String, content: String) {
        viewModelScope.launch {
            if (content.isNotBlank()) {
                val newComment = PostComment(
                    postId = postId,
                    videoId = 0,
                    author = author.ifBlank { "Anonymous Guest" },
                    content = content
                )
                repository.insertComment(newComment)
                triggerSnackbar("Comment posted successfully!")
            }
        }
    }

    fun addVideoComment(videoId: Int, author: String, content: String) {
        viewModelScope.launch {
            if (content.isNotBlank()) {
                val newComment = PostComment(
                    postId = 0,
                    videoId = videoId,
                    author = author.ifBlank { "Anonymous Guest" },
                    content = content
                )
                repository.insertComment(newComment)
                triggerSnackbar("Comment posted successfully!")
            }
        }
    }

    // Newsletter subscription
    fun subscribeNewsletter(email: String) {
        viewModelScope.launch {
            if (email.isNotBlank() && email.contains("@")) {
                repository.insertNewsletterEmail(email)
                triggerSnackbar("Thank you! \"$email\" subscribed to Chronos Newsletter.")
                sendLocalAlert("Newsletter Subscription", "Welcome! You are now subscribed to the Daily Chronos Digest.")
            } else {
                triggerSnackbar("Please enter a valid email address.")
            }
        }
    }

    // Contact Form submission (simulated but tracks client records)
    fun submitContact(name: String, email: String, message: String) {
        viewModelScope.launch {
            triggerSnackbar("Message sent successfully! Our editors will get in touch.")
            sendLocalAlert("Contact Support", "Feedback from $name ($email) was submitted successfully.")
        }
    }

    // Notification systems
    private fun sendLocalAlert(title: String, message: String) {
        viewModelScope.launch {
            repository.insertNotification(title, message)
        }
    }

    fun markNotificationAsRead(id: Int) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun clearNotifications() {
        viewModelScope.launch {
            repository.clearAllNotifications()
            triggerSnackbar("Alert logs cleared.")
        }
    }

    // Helper to get single publication details synchronously within ViewModel launch context
    suspend fun getPostSync(postId: Int): PublishPost? {
        return repository.getPostById(postId)
    }

    // Helper to get single video details synchronously
    suspend fun getVideoSync(videoId: Int): PublishVideo? {
        return repository.getVideoById(videoId)
    }
}

@Suppress("UNCHECKED_CAST")
class ChronosViewModelFactory(private val repository: ChronosRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ChronosViewModel::class.java)) {
            return ChronosViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
