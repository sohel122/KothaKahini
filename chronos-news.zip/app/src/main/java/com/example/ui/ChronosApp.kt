package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChronosAppContent(viewModel: ChronosViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val user by viewModel.currentUser.collectAsStateWithLifecycle()
    val notifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val snackbarMsg by viewModel.snackbarMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMsg) {
        snackbarMsg?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageIconsChronosLogo(),
                            contentDescription = "Chronos Logo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp).padding(end = 6.dp)
                        )
                        Text(
                            text = "Chronos",
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            letterSpacing = 1.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = " 2026",
                            fontWeight = FontWeight.Light,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                },
                navigationIcon = {
                    if (currentScreen !is AppScreen.Home) {
                        IconButton(onClick = { viewModel.navigateBack() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("dark_mode_toggle")
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Dark Mode"
                        )
                    }

                    var showNotifsDropdown by remember { mutableStateOf(false) }
                    IconButton(onClick = { showNotifsDropdown = true }) {
                        Box {
                            val unread = notifications.isNotEmpty()
                            Icon(
                                imageVector = if (unread) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                contentDescription = "Alerts",
                                tint = if (unread) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (unread) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .align(Alignment.TopEnd)
                                        .background(Color.Red, shape = CircleShape)
                                )
                            }
                        }
                    }

                    DropdownMenu(
                        expanded = showNotifsDropdown,
                        onDismissRequest = { showNotifsDropdown = false },
                        modifier = Modifier.width(300.dp).background(MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "System Alerts", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            TextButton(onClick = { viewModel.clearNotifications() }) {
                                Text("Clear", fontSize = 12.sp)
                            }
                        }
                        HorizontalDivider()
                        if (notifications.isEmpty()) {
                            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                Text("No recent notifications.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                            }
                        } else {
                            notifications.take(5).forEach { alert ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(alert.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(alert.message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    onClick = { viewModel.markNotificationAsRead(alert.id) }
                                )
                            }
                        }
                    }

                    ProfileWidget(user, viewModel)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp)
            ) {
                NavigationBarItem(
                    selected = currentScreen is AppScreen.Home,
                    onClick = { viewModel.navigateTo(AppScreen.Home) },
                    label = { Text("Home") },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") }
                )
                NavigationBarItem(
                    selected = currentScreen is AppScreen.BlogList,
                    onClick = { viewModel.navigateTo(AppScreen.BlogList) },
                    label = { Text("Blogs") },
                    icon = { Icon(Icons.Default.Article, contentDescription = "Blogs") }
                )
                NavigationBarItem(
                    selected = currentScreen is AppScreen.VideoList,
                    onClick = { viewModel.navigateTo(AppScreen.VideoList) },
                    label = { Text("Videos") },
                    icon = { Icon(Icons.Default.PlayCircle, contentDescription = "Videos") }
                )
                if (user?.role == "ADMIN") {
                    NavigationBarItem(
                        selected = currentScreen is AppScreen.AdminDashboard,
                        onClick = { viewModel.navigateTo(AppScreen.AdminDashboard) },
                        label = { Text("Admin") },
                        icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin") }
                    )
                }
                NavigationBarItem(
                    selected = currentScreen is AppScreen.AboutContact,
                    onClick = { viewModel.navigateTo(AppScreen.AboutContact) },
                    label = { Text("About") },
                    icon = { Icon(Icons.Default.ContactSupport, contentDescription = "About") }
                )
            }
        },
        floatingActionButton = {
            if (user != null) {
                when (currentScreen) {
                    is AppScreen.BlogList -> {
                        FloatingActionButton(
                            onClick = { viewModel.navigateTo(AppScreen.EditPostScreen(null)) },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.testTag("create_post_fab")
                        ) {
                            Icon(Icons.Default.Create, contentDescription = "Publish Post")
                        }
                    }
                    is AppScreen.VideoList -> {
                        var showUploadModal by remember { mutableStateOf(false) }
                        FloatingActionButton(
                            onClick = { showUploadModal = true },
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        ) {
                            Icon(Icons.Default.VideoCall, contentDescription = "Upload Video")
                        }

                        if (showUploadModal) {
                            NewVideoModalDialog(onDismiss = { showUploadModal = false }, onUpload = { t, d, c, du, vu, th ->
                                viewModel.uploadVideo(t, d, c, du, vu, th)
                                showUploadModal = false
                            })
                        }
                    }
                    else -> {}
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (val screen = currentScreen) {
                is AppScreen.Home -> HomeScreen(viewModel)
                is AppScreen.BlogList -> BlogListScreen(viewModel)
                is AppScreen.VideoList -> VideoListScreen(viewModel)
                is AppScreen.AdminDashboard -> AdminDashboardScreen(viewModel)
                is AppScreen.AboutContact -> AboutContactScreen(viewModel)
                is AppScreen.PostDetail -> PostDetailScreen(screen.postId, viewModel)
                is AppScreen.VideoDetail -> VideoDetailScreen(screen.videoId, viewModel)
                is AppScreen.EditPostScreen -> EditPostScreen(screen.postId, viewModel)
            }
        }
    }
}

// PROFILE LOGIC
@Composable
fun ProfileWidget(user: AppUser?, viewModel: ChronosViewModel) {
    var showAuthDialog by remember { mutableStateOf(false) }
    var showProfileDropdown by remember { mutableStateOf(false) }

    if (user == null) {
        Button(
            onClick = { showAuthDialog = true },
            modifier = Modifier.padding(end = 8.dp).testTag("login_button"),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Text("Login", fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    } else {
        Box(modifier = Modifier.padding(end = 8.dp)) {
            IconButton(
                onClick = { showProfileDropdown = true },
                modifier = Modifier.testTag("profile_avatar")
            ) {
                if (user.avatarUrl.isNotBlank()) {
                    AsyncImage(
                        model = user.avatarUrl,
                        contentDescription = "User Avatar",
                        modifier = Modifier.size(36.dp).clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(MaterialTheme.colorScheme.primary, shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.username.take(1).uppercase(Locale.ROOT),
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            DropdownMenu(
                expanded = showProfileDropdown,
                onDismissRequest = { showProfileDropdown = false }
            ) {
                Text(
                    text = user.username,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontSize = 14.sp
                )
                Text(
                    text = "Role: ${user.role} (${user.email})",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Row {
                        Icon(Icons.Default.Logout, "Logout", modifier = Modifier.size(16.dp).padding(end = 4.dp))
                        Text("Sign Out")
                    }},
                    onClick = {
                        viewModel.logoutUser()
                        showProfileDropdown = false
                    }
                )
            }
        }
    }

    if (showAuthDialog) {
        AuthDialog(
            onDismiss = { showAuthDialog = false },
            onSubmit = { name, email, isAdmin ->
                viewModel.loginUser(name, email, isAdmin)
                showAuthDialog = false
            }
        )
    }
}

@Composable
fun AuthDialog(onDismiss: () -> Unit, onSubmit: (String, String, Boolean) -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var isAdmin by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sign In / Sign Up", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Uzername") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isAdmin, onCheckedChange = { isAdmin = it })
                    Text("Request Administrator (Admin Panel Access)")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank() && email.isNotBlank()) onSubmit(name, email, isAdmin) }
            ) {
                Text("Confirm Credentials")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// 1. HOME SCREEN IMPLEMENTATION
@Composable
fun HomeScreen(viewModel: ChronosViewModel) {
    val posts by viewModel.allPosts.collectAsStateWithLifecycle()
    val videos by viewModel.allVideos.collectAsStateWithLifecycle()
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val query by viewModel.newsSearchQuery.collectAsStateWithLifecycle()
    val selectedCat by viewModel.selectedCategory.collectAsStateWithLifecycle()

    val categories = listOf("All", "Technology", "News", "Breaking", "Local", "International", "Sports", "Lifestyle")

    val blogFeatured = posts.filter { it.isFeatured }
    val trending = posts.filter { it.isTrending }.sortedByDescending { it.likes + it.views }

    val filteredPosts = posts.filter {
        val matchesSearch = it.title.contains(query, ignoreCase = true) || it.content.contains(query, ignoreCase = true) || it.tags.contains(query, ignoreCase = true)
        val matchesCategory = selectedCat == "All" || it.category.equals(selectedCat, ignoreCase = true) || (selectedCat == "News" && it.type == "NEWS")
        matchesSearch && matchesCategory
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Search Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.surfaceVariant,
                                MaterialTheme.colorScheme.background
                            )
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Column {
                    Text(
                        text = "Global Ledger of 2026",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Serif
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Real-time verified publications, video briefs, and SEO-guided meta tools.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = query,
                        onValueChange = { viewModel.setNewsSearchQuery(it) },
                        placeholder = { Text("Search stories, categories, or keywords...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                        trailingIcon = { if (query.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setNewsSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clean")
                            }
                        }},
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                            .testTag("news_search_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        )
                    )
                }
            }
        }

        // Hero Banner: Hero article representation
        if (blogFeatured.isNotEmpty() && query.isEmpty() && selectedCat == "All") {
            item {
                FeaturedHeroBanner(blogFeatured.first()) {
                    viewModel.navigateTo(AppScreen.PostDetail(blogFeatured.first().id))
                }
            }
        }

        // Horizontal Categories Bar
        item {
            ScrollableTabRow(
                selectedTabIndex = categories.indexOf(selectedCat).coerceAtLeast(0),
                edgePadding = 16.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                categories.forEach { cat ->
                    val isSelected = cat == selectedCat
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.setCategory(cat) },
                        modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(20.dp)
                                )
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cat,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Main Publications grid/list
        if (filteredPosts.isEmpty()) {
            item {
                EmptyStateRow(tip = "No articles match the specified filters.")
            }
        } else {
            // Latest publications
            item {
                Text(
                    text = "LATEST PULSE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    letterSpacing = 1.5.sp
                )
            }

            items(filteredPosts) { article ->
                HorizontalArticleCard(article, isDark) {
                    viewModel.incrementPostViews(article)
                    viewModel.navigateTo(AppScreen.PostDetail(article.id))
                }
            }
        }

        // Trending Posts Section (Scroll block)
        if (trending.isNotEmpty() && query.isEmpty() && selectedCat == "All") {
            item {
                Spacer(modifier = Modifier.height(18.dp))
                TrendingRow(trending) { id ->
                    viewModel.navigateTo(AppScreen.PostDetail(id))
                }
            }
        }

        // Latest Video Broadcasts row
        if (videos.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "CHRONOS VIDEO NET",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(videos) { video ->
                        CompactVideoThumbnailCard(video, isDark) {
                            viewModel.incrementVideoViews(video)
                            viewModel.navigateTo(AppScreen.VideoDetail(video.id))
                        }
                    }
                }
            }
        }

        // Newsletter Box
        item {
            NewsletterBox(viewModel)
        }

        // Dedicated Premium Footer
        item {
            ChronosFooter()
        }
    }
}

// 2. BLOG LIST SCREEN
@Composable
fun BlogListScreen(viewModel: ChronosViewModel) {
    val posts by viewModel.allPosts.collectAsStateWithLifecycle()
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()

    val blogsOnly = posts.filter { it.type == "BLOG" }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Transparent)
                    .padding(16.dp)
            ) {
                Column {
                    Text(
                        text = "Essays & Insights",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Long-form editorial blogs, dynamic tag listings, and structured commentary feeds.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (blogsOnly.isEmpty()) {
            item {
                EmptyStateRow(tip = "No user blogs have been published yet. Be the first to create one!")
            }
        } else {
            items(blogsOnly) { blog ->
                VerticalBlogCard(blog, isDark) {
                    viewModel.incrementPostViews(blog)
                    viewModel.navigateTo(AppScreen.PostDetail(blog.id))
                }
            }
        }
    }
}

// 3. VIDEO PLATFORM SCREEN
@Composable
fun VideoListScreen(viewModel: ChronosViewModel) {
    val videos by viewModel.allVideos.collectAsStateWithLifecycle()
    val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val vidQuery by viewModel.videoSearchQuery.collectAsStateWithLifecycle()
    val vidCat by viewModel.selectedVideoCategory.collectAsStateWithLifecycle()

    val videoCategories = listOf("All", "Technology", "Travel", "Nature", "Lifestyle")

    val filteredVideos = videos.filter {
        val matchesSearch = it.title.contains(vidQuery, ignoreCase = true) || it.description.contains(vidQuery, ignoreCase = true)
        val matchesCategory = vidCat == "All" || it.category.equals(vidCat, ignoreCase = true)
        matchesSearch && matchesCategory
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Studio Broadcaster",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "High definition briefs, local video uploaders, and video logs comments.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = vidQuery,
                    onValueChange = { viewModel.setVideoSearchQuery(it) },
                    placeholder = { Text("Search clip titles or briefs...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Video Search") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                        .testTag("video_search_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(videoCategories) { cat ->
                        FilterChip(
                            selected = cat == vidCat,
                            onClick = { viewModel.setVideoCategory(cat) },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
            }
        }

        if (filteredVideos.isEmpty()) {
            item {
                EmptyStateRow("No videos discovered under active keywords.")
            }
        } else {
            items(filteredVideos) { video ->
                LargeShowcaseVideoCard(video, isDark) {
                    viewModel.incrementVideoViews(video)
                    viewModel.navigateTo(AppScreen.VideoDetail(video.id))
                }
            }
        }
    }
}

// 4. DETAILED PUBLICATION CORE READ PAGE
@Composable
fun PostDetailScreen(postId: Int, viewModel: ChronosViewModel) {
    var article by remember { mutableStateOf<PublishPost?>(null) }
    val commentsFlow = remember(postId) { viewModel.getCommentsForPost(postId) }
    val comments by commentsFlow.collectAsStateWithLifecycle(emptyList())
    val user by viewModel.currentUser.collectAsStateWithLifecycle()

    var commentAuthor by remember { mutableStateOf(user?.username ?: "") }
    var commentBody by remember { mutableStateOf("") }

    LaunchedEffect(postId) {
        article = viewModel.getPostSync(postId)
    }

    article?.let { item ->
        val tagsList = item.tags.split(",").map { it.trim() }.filter { it.isNotBlank() }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.category.uppercase(Locale.ROOT),
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                    )
                    Text(
                        text = SimpleDateFormat("MMM dd, 2026", Locale.getDefault()).format(Date(item.timestamp)),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Serif
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(24.dp).background(MaterialTheme.colorScheme.secondary, shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(item.author.take(1), color = MaterialTheme.colorScheme.onSecondary, fontSize = 11.sp)
                    }
                    Text(
                        text = " By ${item.author}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                AsyncImage(
                    model = item.imageUrl,
                    contentDescription = item.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Detail contents
                Text(
                    text = item.content,
                    fontSize = 15.sp,
                    lineHeight = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontFamily = FontFamily.SansSerif
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Tags row
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    tagsList.forEach { tag ->
                        Box(
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "#$tag", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.likePost(item) }) {
                            Icon(Icons.Default.Favorite, "Like", tint = Color.Red.copy(alpha = 0.8f))
                        }
                        Text("${item.likes} Likes", fontSize = 12.sp, modifier = Modifier.padding(end = 12.dp))

                        Icon(Icons.Default.Visibility, "Views", modifier = Modifier.size(16.dp))
                        Text(" ${item.views} views", fontSize = 12.sp)
                    }

                    // SEO Structured schema inspection modal
                    var showSeoSched by remember { mutableStateOf(false) }
                    IconButton(onClick = { showSeoSched = true }) {
                        Icon(Icons.Default.Share, "Share & SEO Specs")
                    }

                    if (showSeoSched) {
                        SeoShareModalDialog(item = item, onDismiss = { showSeoSched = false })
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))

                // Comment list header
                Text("Commentary Feed (${comments.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = FontFamily.Serif)
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (comments.isEmpty()) {
                item {
                    Text("Be the first to share an insight or review.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 16.dp))
                }
            } else {
                items(comments) { comment ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(comment.author, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(comment.timestamp)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(comment.content, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                // Write comment form
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Write Comment", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        OutlinedTextField(
                            value = commentAuthor,
                            onValueChange = { commentAuthor = it },
                            label = { Text("Display Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(6.dp)
                        )
                        OutlinedTextField(
                            value = commentBody,
                            onValueChange = { commentBody = it },
                            label = { Text("Share an opinion...", fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            shape = RoundedCornerShape(6.dp)
                        )
                        Button(
                            onClick = {
                                if (commentBody.isNotBlank()) {
                                    viewModel.addPostComment(item.id, commentAuthor, commentBody)
                                    commentBody = ""
                                }
                            },
                            modifier = Modifier.align(Alignment.End),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, "Send", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Publish Comment", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    } ?: Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

// 5. HIGH FIDELITY SIMULATED VIDEO PLAYER DETAIL SCREEN
@Composable
fun VideoDetailScreen(videoId: Int, viewModel: ChronosViewModel) {
    var video by remember { mutableStateOf<PublishVideo?>(null) }
    val commentsFlow = remember(videoId) { viewModel.getCommentsForVideo(videoId) }
    val comments by commentsFlow.collectAsStateWithLifecycle(emptyList())
    val user by viewModel.currentUser.collectAsStateWithLifecycle()

    var commentAuthor by remember { mutableStateOf(user?.username ?: "") }
    var commentBody by remember { mutableStateOf("") }

    LaunchedEffect(videoId) {
        video = viewModel.getVideoSync(videoId)
    }

    video?.let { item ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp)
        ) {
            // Interactive custom Video Canvas
            item {
                Text(
                    text = item.category.uppercase(Locale.ROOT),
                    color = MaterialTheme.colorScheme.secondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Serif
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))

                SimulatedPlayerCanvas(title = item.title, duration = item.duration, thumbnailUrl = item.thumbnailUrl)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Uploaded by ${item.uploader}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.likeVideo(item) }) {
                            Icon(Icons.Default.ThumbUp, "Like", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                        Text("${item.likes}", fontSize = 12.sp, modifier = Modifier.padding(end = 12.dp))

                        Icon(Icons.Default.RemoveRedEye, "Views", modifier = Modifier.size(16.dp))
                        Text(" ${item.views} clips", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(item.description, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(16.dp))

                Text("Video Comments (${comments.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp, fontFamily = FontFamily.Serif)
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (comments.isEmpty()) {
                item {
                    Text("No clip remarks. Add your thoughts down below.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(comments) { comment ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(comment.author, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                Text(
                                    SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(comment.timestamp)),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(comment.content, fontSize = 12.sp)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
                // Write comment form
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Add Video Comment", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        OutlinedTextField(
                            value = commentAuthor,
                            onValueChange = { commentAuthor = it },
                            label = { Text("Display Tag") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(6.dp)
                        )
                        OutlinedTextField(
                            value = commentBody,
                            onValueChange = { commentBody = it },
                            label = { Text("Type key response...", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            shape = RoundedCornerShape(6.dp)
                        )
                        Button(
                            onClick = {
                                if (commentBody.isNotBlank()) {
                                    viewModel.addVideoComment(item.id, commentAuthor, commentBody)
                                    commentBody = ""
                                }
                            },
                            modifier = Modifier.align(Alignment.End),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Post Comment", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    } ?: Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

// 6. EDIT SCREEN (Blogs or News Publications)
@Composable
fun EditPostScreen(postId: Int?, viewModel: ChronosViewModel) {
    val user by viewModel.currentUser.collectAsStateWithLifecycle()

    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var author by remember { mutableStateOf(user?.username ?: "Guest Author") }
    var isNews by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("Technology") }
    var tags by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }

    val categoriesList = listOf("Technology", "Breaking", "Local", "International", "Sports", "Lifestyle")

    LaunchedEffect(postId) {
        if (postId != null) {
            viewModel.getPostSync(postId)?.let { existing ->
                title = existing.title
                content = existing.content
                author = existing.author
                isNews = existing.type == "NEWS"
                category = existing.category
                tags = existing.tags
                imageUrl = existing.imageUrl
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = if (postId == null) "Launch New Chronicle" else "Edit Core Narrative",
            style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
        )

        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Narrative Title") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Write as Blog", fontSize = 13.sp)
            Switch(checked = isNews, onCheckedChange = { isNews = it }, modifier = Modifier.padding(horizontal = 8.dp))
            Text("Publish as News Wire", fontSize = 13.sp)
        }

        OutlinedTextField(
            value = author,
            onValueChange = { author = it },
            label = { Text("Bylined Author Signature") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        )

        Column {
            Text("Filing Tag / Category", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
                categoriesList.forEach { cat ->
                    val isSel = cat == category
                    FilterChip(
                        selected = isSel,
                        onClick = { category = cat },
                        label = { Text(cat) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }
        }

        OutlinedTextField(
            value = tags,
            onValueChange = { tags = it },
            label = { Text("Core Meta Tags (comma separated, e.g. ai, tech)") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        )

        OutlinedTextField(
            value = imageUrl,
            onValueChange = { imageUrl = it },
            label = { Text("Direct Content Image URL (optional placeholder)") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            placeholder = { Text("https://images.unsplash.com/photo-...") }
        )

        OutlinedTextField(
            value = content,
            onValueChange = { content = it },
            label = { Text("Editorial Narrative Content (Body Text)") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 8,
            shape = RoundedCornerShape(8.dp)
        )

        Button(
            onClick = {
                if (title.isNotBlank() && content.isNotBlank()) {
                    if (postId == null) {
                        viewModel.addPost(title, content, author, if (isNews) "NEWS" else "BLOG", category, tags, imageUrl)
                    } else {
                        viewModel.updatePost(postId, title, content, author, if (isNews) "NEWS" else "BLOG", category, tags, imageUrl)
                    }
                    viewModel.navigateBack()
                } else {
                    viewModel.triggerSnackbar("Title and content cannot be blank!")
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("submit_post_button"),
            shape = RoundedCornerShape(8.dp)
        ) {
            Icon(Icons.Default.Done, "Save")
            Spacer(modifier = Modifier.width(6.dp))
            Text("Commit Publication", fontWeight = FontWeight.Bold)
        }
    }
}

// 7. COMPREHENSIVE ADMIN PANEL SCREEN
@Composable
fun AdminDashboardScreen(viewModel: ChronosViewModel) {
    val posts by viewModel.allPosts.collectAsStateWithLifecycle()
    val videos by viewModel.allVideos.collectAsStateWithLifecycle()
    val users by viewModel.allUsers.collectAsStateWithLifecycle()
    val newsletters by viewModel.allNewsletterEmails.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf("Dashboard") } // "Dashboard", "Publications", "Clips", "Settings"

    Column(modifier = Modifier.fillMaxSize()) {
        // Horizontal Control Pills
        ScrollableTabRow(
            selectedTabIndex = when(activeTab) {
                "Dashboard" -> 0
                "Publications" -> 1
                "Clips" -> 2
                "Settings" -> 3
                else -> 0
            },
            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
        ) {
            Tab(selected = activeTab == "Dashboard", onClick = { activeTab = "Dashboard" }) {
                Text("Metrics Summary", modifier = Modifier.padding(14.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeTab == "Publications", onClick = { activeTab = "Publications" }) {
                Text("Manage Posts", modifier = Modifier.padding(14.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeTab == "Clips", onClick = { activeTab = "Clips" }) {
                Text("Manage Videos", modifier = Modifier.padding(14.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Tab(selected = activeTab == "Settings", onClick = { activeTab = "Settings" }) {
                Text("SEO Engine & Config", modifier = Modifier.padding(14.dp).testTag("admin_seo_tab"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        when (activeTab) {
            "Dashboard" -> {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    item {
                        Text("Core Analytical KPIs", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Stats counters
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.weight(1f).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(8.dp)).padding(12.dp)) {
                                Column {
                                    Text("Publications", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    Text("${posts.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Box(modifier = Modifier.weight(1f).background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(8.dp)).padding(12.dp)) {
                                Column {
                                    Text("Video Clips", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                    Text("${videos.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.weight(1f).background(MaterialTheme.colorScheme.tertiaryContainer, RoundedCornerShape(8.dp)).padding(12.dp)) {
                                Column {
                                    Text("User Cards", fontSize = 11.sp, color = MaterialTheme.colorScheme.onTertiaryContainer)
                                    Text("${users.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Box(modifier = Modifier.weight(1f).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(12.dp)) {
                                Column {
                                    Text("Digest Subs", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${newsletters.size}", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Text("Chronos Traffic Analytics (Real-Time)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text("Live visualization of content impressions inside local db memory on June 2026.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(10.dp))

                        // High fidelity analytic graph using canvas
                        SleekAnalyticsCanvas()

                        Spacer(modifier = Modifier.height(18.dp))
                        Text("Active Newsletter Subscriptions List", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    if (newsletters.isEmpty()) {
                        item {
                            Text("No emails subscribed yet.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    } else {
                        items(newsletters) { sub ->
                            Row(
                                modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)).padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(sub.email, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(sub.timestamp)),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }

            "Publications" -> {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(posts) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                        ) {
                            Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("Bylined: ${item.author} • ${item.type} • ${item.category}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Row {
                                    IconButton(onClick = { viewModel.navigateTo(AppScreen.EditPostScreen(item.id)) }) {
                                        Icon(Icons.Default.Edit, "Edit", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                    }
                                    IconButton(onClick = { viewModel.deletePost(item.id, item.title) }) {
                                        Icon(Icons.Default.Delete, "Delete", tint = Color.Red.copy(alpha = 0.8f), modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "Clips" -> {
                LazyColumn(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(videos) { clip ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                        ) {
                            Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(clip.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
                                    Text("Channel: ${clip.uploader} • Duration: ${clip.duration} • ${clip.category}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { viewModel.deleteVideo(clip.id, clip.title) }) {
                                    Icon(Icons.Default.Delete, "Delete", tint = Color.Red, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }

            "Settings" -> {
                SEOConfigPanel(posts, viewModel)
            }
        }
    }
}

// 8. INTERACTIVE ABOUT & CONTACT CORE COMBINED PAGE
@Composable
fun AboutContactScreen(viewModel: ChronosViewModel) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    val coreFaq = listOf(
        "Is this app production ready for news operations?" to "Yes, Chronos integrates robust on-device SQL Room databases that easily sync local posts, user directories, and system newsletters seamlessly.",
        "What SEO structures does the app support?" to "We support automated SiteMap models, copyable Robots restrictions, and real-time generation of Open Graph tags and Google JSON-LD structured schemas on all detailed items."
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Mission manifesto
        item {
            Text(
                "Editorial Statement",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Serif
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "We believe in high-contrast editorial elegance. Our platform is optimized to deliver raw information briefs, sports reports, and modern engineering blogs without clutter or auto-playing visual fatigue.",
                fontSize = 13.sp,
                lineHeight = 20.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Contact Support Form
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Reach Editorial Desk", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
                    Text("Send tips, copyright notifications, or press coordinates directly.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Your Signature / Name") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Contact Email Address") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                    )
                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("Message details...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Button(
                        onClick = {
                            if (name.isNotBlank() && email.isNotBlank() && message.isNotBlank()) {
                                viewModel.submitContact(name, email, message)
                                name = ""
                                email = ""
                                message = ""
                            } else {
                                viewModel.triggerSnackbar("All fields are mandatory!")
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("contact_submit_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Send, "Send")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Transmit Feedback Tip")
                    }
                }
            }
        }

        // FAQ section
        item {
            Text("Publishing FAQs", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
            Spacer(modifier = Modifier.height(6.dp))
            coreFaq.forEach { faq ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(faq.first, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(faq.second, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Legal Disclaimers
        item {
            HorizontalDivider()
            Spacer(modifier = Modifier.height(10.dp))
            Text("Privacy Covenant & Terms of Use", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                "Your information privacy is tightly bound. Chronos operates fully in offline local memory sandbox. We do not transmit coordinates or cookies to third-party databases unless explicitly authorized for site analysis. All newsletter subscription inputs remain encrypted locally.",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text("© 2026 Chronos Media Group. All rights reserved globally.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// CUSTOM CANVAS ANALYTICS WIDGET
@Composable
fun SleekAnalyticsCanvas() {
    val graphColor = MaterialTheme.colorScheme.primary
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .background(MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp), RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Render grid lines
            val gridCount = 4
            for (i in 0..gridCount) {
                val y = height * i / gridCount
                drawLine(
                    color = labelColor.copy(alpha = 0.1f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            // Simulated impressions: views trends on 5 consecutive days of June 2026
            val points = listOf(0.1f, 0.45f, 0.3f, 0.82f, 0.95f)
            val stepX = width / (points.size - 1)

            val path = Path()
            path.moveTo(0f, height * (1f - points[0]))

            for (i in 1 until points.size) {
                val currentX = i * stepX
                val currentY = height * (1f - points[i])
                path.lineTo(currentX, currentY)
            }

            drawPath(
                path = path,
                color = graphColor,
                style = Stroke(width = 3.dp.toPx())
            )

            // Fill gradient under curves
            val fillPath = Path().apply {
                addPath(path)
                lineTo(width, height)
                lineTo(0f, height)
                close()
            }
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(graphColor.copy(alpha = 0.3f), Color.Transparent)
                )
            )

            // Dynamic points
            for (i in points.indices) {
                drawCircle(
                    color = graphColor,
                    center = Offset(i * stepX, height * (1f - points[i])),
                    radius = 5.dp.toPx()
                )
            }
        }
    }
}

// SEO CONFIG AND METADATA GENERATION CARD
@Composable
fun SEOConfigPanel(posts: List<PublishPost>, viewModel: ChronosViewModel) {
    val clipMgr = LocalClipboardManager.current
    var selPostForSchema by remember { mutableStateOf(posts.firstOrNull()) }

    var sitemapText by remember { mutableStateOf("") }
    var robotsText by remember { mutableStateOf("") }

    LaunchedEffect(posts, selPostForSchema) {
        // Sitemap generator
        val sMap = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n")
        posts.forEach { item ->
            sMap.append("  <url>\n")
            sMap.append("    <loc>https://chronos-news.com/publications/${item.id}</loc>\n")
            sMap.append("    <lastmod>2026-06-18</lastmod>\n")
            sMap.append("    <changefreq>daily</changefreq>\n")
            sMap.append("  </url>\n")
        }
        sMap.append("</urlset>")
        sitemapText = sMap.toString()

        // Robots.txt generator
        robotsText = "User-agent: *\nDisallow: /admin/\nDisallow: /private/\n\nSitemap: https://chronos-news.com/sitemap.xml"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Search Engine Calibration (SEO Toolset)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, fontFamily = FontFamily.Serif)
        Text("Generate indexable XML schemas, Open Graph tags, and structure meta protocols for web compliance.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        // Robots.txt inspector
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text("robots.txt", fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text(robotsText, fontFamily = FontFamily.Monospace, fontSize = 10.sp, modifier = Modifier.padding(vertical = 4.dp))
                Button(
                    onClick = {
                        clipMgr.setText(AnnotatedString(robotsText))
                        viewModel.triggerSnackbar("robots.txt copied to clipboard!")
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Copy robots.txt", fontSize = 10.sp)
                }
            }
        }

        // Sitemap.xml inspector
        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text("sitemap.xml (Pre-calibrated Indexes)", fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Box(modifier = Modifier.height(100.dp).verticalScroll(rememberScrollState())) {
                    Text(sitemapText, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                }
                Button(
                    onClick = {
                        clipMgr.setText(AnnotatedString(sitemapText))
                        viewModel.triggerSnackbar("sitemap.xml copied!")
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Copy sitemap.xml", fontSize = 10.sp)
                }
            }
        }

        // Selected structured schema JSON LD
        Text("Select Post to Inspector JSON-LD Schema", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Box(modifier = Modifier.height(80.dp).verticalScroll(rememberScrollState())) {
            Row {
                posts.forEach { item ->
                    val isS = item.id == selPostForSchema?.id
                    FilterChip(
                        selected = isS,
                        onClick = { selPostForSchema = item },
                        label = { Text(item.title.take(15) + "...", fontSize = 10.sp) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                }
            }
        }

        selPostForSchema?.let { selected ->
            val jsonLd = """{
  "@context": "https://schema.org",
  "@type": "NewsArticle",
  "headline": "${selected.title}",
  "image": [
    "${selected.imageUrl}"
  ],
  "datePublished": "2026-06-18T08:00:00Z",
  "author": [{
    "@type": "Person",
    "name": "${selected.author}",
    "url": "https://chronos-news.com/author/${selected.author.lowercase()}"
  }]
}"""
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Google Search Console Schema (JSON-LD)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Box(modifier = Modifier.height(120.dp).verticalScroll(rememberScrollState())) {
                        Text(jsonLd, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                    }
                    Button(
                        onClick = {
                            clipMgr.setText(AnnotatedString(jsonLd))
                            viewModel.triggerSnackbar("JSON-LD copied!")
                        },
                        modifier = Modifier.align(Alignment.End).testTag("seo_meta_copy_button")
                    ) {
                        Text("Copy Google Schema", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// COMPACT VIDEO THUMBNAIL COMPONENT
@Composable
fun CompactVideoThumbnailCard(video: PublishVideo, isDark: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(140.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
    ) {
        Column {
            Box(modifier = Modifier.fillMaxWidth().height(90.dp)) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(Color.Black.copy(alpha = 0.6f), shape = CircleShape)
                        .align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Box(
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.7f), shape = RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                        .align(Alignment.BottomEnd)
                ) {
                    Text(video.duration, color = Color.White, fontSize = 9.sp)
                }
            }
            Text(
                video.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(6.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// LARGE SHOWCASE VIDEO CARD
@Composable
fun LargeShowcaseVideoCard(video: PublishVideo, isDark: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
    ) {
        Column {
            Box(modifier = Modifier.fillMaxWidth().height(180.dp)) {
                AsyncImage(
                    model = video.thumbnailUrl,
                    contentDescription = video.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.8f), shape = CircleShape)
                        .align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, "Play", tint = Color.White, modifier = Modifier.size(28.dp))
                }
                Box(
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                        .align(Alignment.BottomEnd)
                ) {
                    Text(video.duration, color = Color.White, fontSize = 10.sp)
                }
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Text(video.category.uppercase(Locale.ROOT), fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(video.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(video.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

// SIMULATED VIDEO PLAYER CANVAS
@Composable
fun SimulatedPlayerCanvas(title: String, duration: String, thumbnailUrl: String) {
    var isPlaying by remember { mutableStateOf(false) }
    var playPercent by remember { mutableStateOf(0.15f) }

    // Live Progress ticking simulator when active
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isPlaying && playPercent < 1f) {
                kotlinx.coroutines.delay(1000)
                playPercent += 0.015f
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(200.dp)
            .background(Color.Black, RoundedCornerShape(12.dp))
    ) {
        if (!isPlaying) {
            AsyncImage(
                model = thumbnailUrl,
                contentDescription = "Placeholder clip",
                modifier = Modifier.fillMaxSize().alpha(0.6f),
                contentScale = ContentScale.Crop
            )
        } else {
            // Noise effect behind simulated screens
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawBehind {
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF1E293B), Color.Black),
                                center = Offset(size.width / 2, size.height / 2)
                            )
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.MovieFilter, "Video stream", tint = Color.LightGray, modifier = Modifier.size(36.dp))
                    Text("Streaming Digital Broadcast Feed", color = Color.LightGray, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("Buffer speed: 120 Mbps • 1080p", color = Color.Gray, fontSize = 9.sp)
                }
            }
        }

        // Overlay controls
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            // Upper credentials
            Row(
                modifier = Modifier.fillMaxWidth().align(Alignment.TopStart),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(modifier = Modifier.background(Color.Red, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                    Text("LIVE 2026", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                }
                Text("HD Stream", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
            }

            // Central control
            IconButton(
                onClick = { isPlaying = !isPlaying },
                modifier = Modifier.size(48.dp).background(Color.Black.copy(alpha = 0.5f), shape = CircleShape).align(Alignment.Center)
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Trigger",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Lower play timeline
            Column(modifier = Modifier.fillMaxWidth().align(Alignment.BottomStart)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Playback: ${ (playPercent*100).toInt()}%", color = Color.White, fontSize = 9.sp)
                    Text(duration, color = Color.White, fontSize = 9.sp)
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { playPercent },
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.White.copy(alpha = 0.3f),
                    modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

// 9. NEW VIDEO DIALOG PORTAL
@Composable
fun NewVideoModalDialog(onDismiss: () -> Unit, onUpload: (String, String, String, String, String, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("Technology") }
    var dur by remember { mutableStateOf("3:45") }
    var thumb by remember { mutableStateOf("") }

    val categories = listOf("Technology", "Travel", "Nature", "Lifestyle")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stream Upload Terminal", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Short Title") })
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Video Abstract Brief") })

                Text("Subject category:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                    categories.forEach { c ->
                        FilterChip(selected = c == cat, onClick = { cat = c }, label = { Text(c, fontSize = 10.sp) })
                    }
                }

                OutlinedTextField(value = dur, onValueChange = { dur = it }, label = { Text("Video Clip Duration") }, placeholder = { Text("e.g. 2:30") })
                OutlinedTextField(value = thumb, onValueChange = { thumb = it }, label = { Text("Thumbnail Unsplash URL (optional)") })
            }
        },
        confirmButton = {
            Button(onClick = { if (title.isNotBlank()) onUpload(title, desc, cat, dur, "", thumb) }) {
                Text("Broadcast Release")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Abort") }
        }
    )
}

// FEATURED HERO BANNER
@Composable
fun FeaturedHeroBanner(post: PublishPost, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clickable { onClick() }
            .testTag("featured_story_card"),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth().height(200.dp)) {
            // Fallback load
            Image(
                painter = painterResource(id = R.drawable.img_hero_banner),
                contentDescription = "Featured Banner Background",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Gradient scrim
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                        )
                    )
            )

            // Content card details
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "FEATURED COVERAGE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = post.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    maxLines = 2,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Bylined: ${post.author} • ${post.category}",
                    color = Color.LightGray,
                    fontSize = 11.sp
                )
            }
        }
    }
}

// HORIZONTAL ARTICLE CARD
@Composable
fun HorizontalArticleCard(article: PublishPost, isDark: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
        )
    ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (article.imageUrl.isNotBlank()) {
                AsyncImage(
                    model = article.imageUrl,
                    contentDescription = article.title,
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = article.category.uppercase(Locale.ROOT),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                    Text(
                        text = SimpleDateFormat("MMM dd", Locale.getDefault()).format(Date(article.timestamp)),
                        fontSize = 9.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = article.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontFamily = FontFamily.Serif
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "By ${article.author}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// VERTICAL BLOG CARD
@Composable
fun VerticalBlogCard(blog: PublishPost, isDark: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
    ) {
        Column {
            if (blog.imageUrl.isNotBlank()) {
                AsyncImage(
                    model = blog.imageUrl,
                    contentDescription = blog.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentScale = ContentScale.Crop
                )
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = blog.category.uppercase(Locale.ROOT) + " - ESSAY",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(blog.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(blog.content, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Author: ${blog.author}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(blog.timestamp)),
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

// TRENDING DISPLAY ITEMS ROW
@Composable
fun TrendingRow(trending: List<PublishPost>, onSelect: (Int) -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Text(
            text = "TRENDING RECORDS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 1.5.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        trending.take(3).forEachIndexed { index, item ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(item.id) }
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Large numeral index
                Text(
                    text = "0${index + 1}",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.width(48.dp)
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        item.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontFamily = FontFamily.Serif
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "Bylined: ${item.author} in ${item.category} • ${item.likes} Likes",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            HorizontalDivider(modifier = Modifier.padding(start = 48.dp))
        }
    }
}

// NEWSLETTER SUBSCRIPTION COMPONENT
@Composable
fun NewsletterBox(viewModel: ChronosViewModel) {
    var emailAddress by remember { mutableStateOf("") }
    val focusManager = LocalFocusManager.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "Subscribe to the Digest",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
                "Receive high-fidelity summaries and daily tech releases directly inside local client folder archives.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = emailAddress,
                    onValueChange = { emailAddress = it },
                    placeholder = { Text("Your Email Address", fontSize = 12.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
                        .testTag("newsletter_email_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    )
                )

                Button(
                    onClick = {
                        if (emailAddress.isNotBlank()) {
                            viewModel.subscribeNewsletter(emailAddress)
                            emailAddress = ""
                            focusManager.clearFocus()
                        }
                    },
                    modifier = Modifier.testTag("newsletter_submit_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Subscribe", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// DETAILED SEO SCHEMA INSPECTION MODAL Dialog
@Composable
fun SeoShareModalDialog(item: PublishPost, onDismiss: () -> Unit) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current

    val shareRawText = "Read \"${item.title}\" by ${item.author} at Chronos News 2026: https://chronos-news.com/publications/${item.id}"

    val jsonSchema = """{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "${item.title}",
  "author": {
    "@type": "Person",
    "name": "${item.author}"
  },
  "genre": "${item.category}",
  "url": "https://chronos-news.com/publications/${item.id}"
}"""

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("SEO Schema & Share Interface", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Standard Share Link", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                OutlinedTextField(
                    value = shareRawText,
                    onValueChange = {},
                    readOnly = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(4.dp)
                )
                Button(
                    onClick = {
                        clip.setText(AnnotatedString(shareRawText))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.ContentCopy, "Copy Link", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy Share URL", fontSize = 11.sp)
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Rendered Article Scheme (JSON-LD)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .verticalScroll(rememberScrollState())
                        .padding(6.dp)
                ) {
                    Text(jsonSchema, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
                }
                Button(
                    onClick = {
                        clip.setText(AnnotatedString(jsonSchema))
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Default.ContentCopy, "Copy Schema", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy Structured JSON-LD", fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

// EMPTY STATE ROW
@Composable
fun EmptyStateRow(tip: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Empty State Icon",
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = tip, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// REUSABLE PREMIUM STATIC CHRONOS FOOTER
@Composable
fun ChronosFooter() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Chronos Applet", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Text("Local SQL Archive", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Web SEO Desk", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                Text("Schema Engine", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Secure Channel", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary)
                Text("Sandboxed App", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

        // Social Media simulate
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Default.Language, "X Web", modifier = Modifier.size(20.dp).alpha(0.7f))
            Icon(Icons.Default.Campaign, "Press Hub", modifier = Modifier.size(20.dp).alpha(0.7f))
            Icon(Icons.Default.SupportAgent, "Support Desk", modifier = Modifier.size(20.dp).alpha(0.7f))
        }

        Text(
            text = "Chronos Professional News of 2026. Made with true precision, zero unsolicited scripts. Registered Trademark.",
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 4.dp),
            lineHeight = 14.sp
        )
    }
}

// LOGO AND CUSTOM ICONS AS GRAPHIC OBJECTS
fun imageIconsChronosLogo() = Icons.Default.Newspaper
